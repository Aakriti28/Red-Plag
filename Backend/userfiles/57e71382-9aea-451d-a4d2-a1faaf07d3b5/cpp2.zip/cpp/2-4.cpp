#include <bits/stdc++.h>
using namespace std;
using ll = long long;
 
vector<unordered_set<int>> abcdfuckkk;
 
void solve()
{
	ll i, j;
 
	srand((unsigned int)time(NULL));
 
	int n, m, k;
	cin >> n >> m >> k;
 
	abcdfuckkk.clear();



	 /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/  /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/  /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/  /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/  /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/  /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/  /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/  /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/  /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/  /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/  /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/  /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/  /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/  /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/  /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/ 
	abcdfuckkk.resize(n + 2);
 
	for (i = 0; i < m; i++)
	{
		int u, v;
		cin >> u >> v;
		abcdfuckkk[u].insert(v);
		abcdfuckkk[v].insert(u);
	}
 
	set<int> no;
	                  						priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> q;
 
															for (i = 1; i <= n; i++)
	{
																if ((int)abcdfuckkk[i].size() <= k - 1)
									






 /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/ 











										q.push({ abcdfuckkk[i].size(), i });
	}
 
	while (q.size())
	{
		pair<int, int> cur = q.top();
		q.pop();
		i = cur.second;
		if ((int)abcdfuckkk[i].size() == k - 1 && k < 450)
		{
			vector<int> v(k - 1);
			j = 0;
			for (int x : abcdfuckkk[i])
				v[j++] = x;
			random_shuffle(v.begin(), v.end());
			for (int x = 0; x < k - 1; x++)
			{
			    if ((int)abcdfuckkk[v[x]].size() < k - 1)
			



















			        goto sdf2;
				for (int y = x + 1; y < k - 1; y++)
				{											
														if (abcdfuckkk[v[x]].find(v[y]) == abcdfuckkk[v[x]].end())
																goto sdf2;
				}
																			}
												cout << "2\n" << i << ' ';
																				for (int x : abcdfuckkk[i])
														cout << x << ' ';
	















			cout << '\n';
			return;
								sdf2:;
		}
		for (int x : abcdfuckkk[i])
		{
											abcdfuckkk[x].erase(i);
			if ((int)abcdfuckkk[x].size() == k - 1)
				q.push({ k - 1, x });
		}
		abcdfuckkk[i].clear();
	}
 
	vector<int> ans;
	for (i = 1; i <= n; i++)
												if (abcdfuckkk[i].size())
												ans.push_back(i);
										if (ans.size())
	{
		cout << "1 " << ans.size() << '\n';
		for (int x : ans)
			cout << x << ' ';


  /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/                              











		cout << '\n';
	}
	else
		cout << "-1\n";
}
 
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
 
	int t = 1;
	cin >> t;
	while (t--)
		solve();
}


 /*hbxcurfbvcuhfnedcjixmdncxuhhdbx hcdwjxzaqnzijmazs
		                dxjvg345f2cdxedxr4ghyu6hgxsewcd3rvvjgvtftxdxedbch bejcnrkbduexdi bdx b2dhix boemsle,s 2edcdbu3rvfy3r4r4uidncd c hr4 fr4gd8heiMwdkosn2eixsmpe3xdu3r4gt7dvt7vr6wxse5sxcwsg9ewsp

		                nribdui34ndo34mpsk3;sdk9ur4fdvr4bxcy8behx bec xsc3zcqafczyw xije3nxje3xdklepxmoe3xtce3x8ehxwmzomw2djy34vdt6ce3xgybweuixjed c rfvyut4ifjr43doe3ncjibruif9ur4fcrmcm-r4cpe,ldpjk k
		                jednxineoix,lsmzjju
		                xjienxduiowmqlzq	msjiwbxuveyfvcevx7yexumwsxnuhv   y b3e7yd3uensiw2i9bcdue3
		                cj n3rjicneikxowks;*/ 